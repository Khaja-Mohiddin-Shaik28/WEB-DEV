console.log(1);
console.log(2);
console.log(3);

setTimeout(remainingNumbers, 4000);

function remainingNumbers(){
        console.log("------------------------------------");
        console.log(4);
        console.log(5);
        console.log(6);
}
console.log(7);
console.log(8);
console.log(9);